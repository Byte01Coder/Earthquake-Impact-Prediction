# train_model.py

import joblib
import numpy as np
from pathlib import Path
from sklearn.datasets import load_iris
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

def main():
    # 1) Loading dataset
    iris = load_iris(as_frame=True)
    X = iris.data.values  # shape (150, 4)
    y = iris.target.values  # 0,1,2

    # 2) Split (train/test) 
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    # 3) Scale features
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled  = scaler.transform(X_test)

    # 4) Train model
    model = LogisticRegression(max_iter=1000, multi_class="auto", random_state=42)
    model.fit(X_train_scaled, y_train)

    # 5) Evaluating
    acc = model.score(X_test_scaled, y_test)
    print(f"Test Accuracy: {acc:.3f}")

    # 6) Saving artifacts
    models_dir = Path(__file__).resolve().parent / "models"
    models_dir.mkdir(parents=True, exist_ok=True)

    joblib.dump(model, models_dir / "model.pkl")
    joblib.dump(scaler, models_dir / "scaler.pkl")
    print(f"Saved model and scaler to: {models_dir}")

if __name__ == "__main__":
    main()
