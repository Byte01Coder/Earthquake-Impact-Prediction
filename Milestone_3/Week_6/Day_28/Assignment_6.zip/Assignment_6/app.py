# app.py

import joblib
import numpy as np
import pandas as pd
import streamlit as st
from pathlib import Path
from sklearn.datasets import load_iris

st.set_page_config(page_title="Iris Classifier • Streamlit", layout="wide")

@st.cache_data
def load_iris_df():
    iris = load_iris(as_frame=True)
    df = iris.frame.copy()
    df.rename(columns={
        "sepal length (cm)": "sepal_length",
        "sepal width (cm)": "sepal_width",
        "petal length (cm)": "petal_length",
        "petal width (cm)": "petal_width",
    }, inplace=True)
    return df, iris.target_names

def load_artifacts():
    models_dir = Path(__file__).resolve().parent / "models"
    model_path = models_dir / "model.pkl"
    scaler_path = models_dir / "scaler.pkl"
    model = scaler = None
    if model_path.exists() and scaler_path.exists():
        model  = joblib.load(model_path)
        scaler = joblib.load(scaler_path)
    return model, scaler

def predict_sample(model, scaler, features_array):
    # features_array shape: (1,4)
    X_scaled = scaler.transform(features_array)
    proba = model.predict_proba(X_scaled)[0]
    pred  = int(np.argmax(proba))
    return pred, proba

st.sidebar.title("Navigation")
mode = st.sidebar.radio("Choose mode", ["Prediction", "Data Exploration"])

# App Header
st.title("Iris Classification — App")
st.markdown(
    "App to explore the Iris dataset and make predictions with a trained Logistic Regression model."
)

df, target_names = load_iris_df()

# Prediction Mode 
if mode == "Prediction":
    st.subheader("Enter Features")
    col1, col2 = st.columns(2)

    with col1:
        sepal_length = st.slider(
            "Sepal Length (cm)",
            float(df["sepal_length"].min()), float(df["sepal_length"].max()),
            float(df["sepal_length"].mean()),
            help="Length of the sepal in centimeters"
        )
        sepal_width = st.slider(
            "Sepal Width (cm)",
            float(df["sepal_width"].min()), float(df["sepal_width"].max()),
            float(df["sepal_width"].mean()),
            help="Width of the sepal in centimeters"
        )
    with col2:
        petal_length = st.slider(
            "Petal Length (cm)",
            float(df["petal_length"].min()), float(df["petal_length"].max()),
            float(df["petal_length"].mean()),
            help="Length of the petal in centimeters"
        )
        petal_width = st.slider(
            "Petal Width (cm)",
            float(df["petal_width"].min()), float(df["petal_width"].max()),
            float(df["petal_width"].mean()),
            help="Width of the petal in centimeters"
        )

    user_feats = np.array([[sepal_length, sepal_width, petal_length, petal_width]], dtype=float)

    st.divider()
    st.subheader("Prediction")

    model, scaler = load_artifacts()
    if (model is None) or (scaler is None):
        st.error("Model not found. Please run `python train_model.py` first to create ./models/model.pkl and scaler.pkl.")
    else:
        pred, proba = predict_sample(model, scaler, user_feats)
        pred_name = target_names[pred]

        # Color-coded result
        color_map = {0: "#e0f7fa", 1: "#f1f8e9", 2: "#fff3e0"}
        box_style = f"background-color:{color_map.get(pred, '#eeeeee')};padding:1rem;border-radius:0.75rem;border:1px solid #ddd;color:black;"
        st.markdown(f"<div style='{box_style}'><b>Predicted class:</b> {pred_name}</div>", unsafe_allow_html=True)

        # Probabilities
        prob_df = pd.DataFrame([proba], columns=target_names)
        st.markdown("**Prediction probabilities:**")
        st.dataframe(prob_df.style.format("{:.3f}"), use_container_width=True)

        with st.expander("Show input as a table"):
            st.write(pd.DataFrame(user_feats, columns=df.columns[:4]))

# Exploration Mode
else:
    st.subheader("Dataset Overview")
    st.write(df.head())

    st.markdown("### Histogram")
    feature_for_hist = st.selectbox("Select feature", df.columns[:4], index=0)
    bins = st.slider("Number of bins", 5, 50, 20)
    st.bar_chart(np.histogram(df[feature_for_hist], bins=bins)[0])

    st.markdown("### Scatter Plot")
    colA, colB = st.columns(2)
    with colA:
        x_feature = st.selectbox("X-axis feature", df.columns[:4], index=0, key="x")
    with colB:
        y_feature = st.selectbox("Y-axis feature", df.columns[:4], index=1, key="y")

    import altair as alt
    scatter = alt.Chart(df).mark_circle(size=60).encode(
        x=alt.X(x_feature, title=x_feature.replace("_", " ").title()),
        y=alt.Y(y_feature, title=y_feature.replace("_", " ").title()),
        color=alt.Color('target:N', title='Species', scale=alt.Scale(scheme='category10')),
        tooltip=list(df.columns)
    ).interactive()
    st.altair_chart(scatter, use_container_width=True)

